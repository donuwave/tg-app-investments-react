import { SInactiveBadge } from "./inactiveBadge.styles";

export const InactiveBadge = () => {
  return <SInactiveBadge>Выбрать</SInactiveBadge>;
};
