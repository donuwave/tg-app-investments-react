export * from "./ui/InvestmentPrice/InvestmentPrice";
export * from "./ui/InvestmentCard/InvestmentCard";
export * from "./ui/InvestmentInWordCard/InvestmentInWordCard";

export * from "./model/investmentCard.types";
