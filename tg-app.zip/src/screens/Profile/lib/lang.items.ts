export const languages = [
  { key: "en", label: "Английский" },
  { key: "ru", label: "Русский" },
];
